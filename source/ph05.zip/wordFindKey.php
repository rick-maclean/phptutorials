<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Word Find Answer Key</title>
</head>
<body>

<?
//answer key for word find
//called from wordFind.php

print <<<HERE
<center>
<h1>$puzzleName Answer key</h1>
$key
</center>

HERE;
?>
</body>
</html>
