<html>
<head>
<title>calculator</title>
</head>
<body>
<center>
<h1>
Calculator</h1>
</center>
<?  

if ($x == null){
  print <<< END
  
  <form>
  x:
  <input type = "text"
         name = "x"
         value = "4">
  <br>
  y:
  <input type = "text"
         name = "y"
         value = "2">
  <br>
  <input type = "submit"
         value = "do the math">
  </form>
END;
} else {
  print "$x + $y = ";
  print $x + $y . "<br> \n";
  print "$x - $y = ";
  print $x - $y . "<br> \n";
  print "$x * $y = " . $x * $y . "<br> \n";
  print "$x / $y = " . $x / $y . "<br> \n";
  print "<form> \n";
  $x = null;
  print '<input type = "submit"
                value = "try new numbers">';
  print "</form>";
} // end if

?>
</body>
</html>

