<html>
<head>
<title>Hi User</title>
</head>
<body>
<h1>Hi User</h1>
<h3>PHP program that receives a value from "whatsName"</h3>

<?

  print "<h3>Hi there, $userName!</h3>";

?>

</body>
</html>