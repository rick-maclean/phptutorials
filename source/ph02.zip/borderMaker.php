<html>
<head>
<title>Your Output</title>
</head>
<body>
<h1>Your Output</h1>
<center>
<?
$theStyle = <<<HERE
"border-width:$borderSize$sizeType;
border-style:$borderStyle;
border-color:green"
HERE;

print "<div style = $theStyle>";
print $basicText;
print "</span>";

?>
</center>

</body>
</html>