<html>
<head>
<title>Hi Jacob</title>
</head>
<body>
<h1>Hi Jacob</h1>

<h3>Demonstrates using a variable</h3>

<?

$userName = "Jacob";

print "Hi, $userName"

?>
</body>
</html>

