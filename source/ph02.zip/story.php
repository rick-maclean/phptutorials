<html>
<head>
<title>Little Boy Who?</title>
</head>
<body>
<center>

<h1>Little Boy Who?</h1>


<?

print <<<HERE
<h3>
Little Boy $color, come blow your $instrument!<br>
The $anim1's in the $place, the $anim2's in the $vegetable.<br>
Where's the boy that looks after the $anim3?<br>
He's under the $structure, $action.
</h3>
HERE;
?>

</center>

</body>
</html>

