<html>
<head>
<title>Little Boy Who?</title>
</head>
<body>
<h1>Little Boy Who?</h1>

<h3>Values from the story page</h3>

<table border = 1>
<tr>
  <th>Variable</th>
  <th>Value</th>
</tr>

<tr>
  <th>color</th>
  <td><? print $color ?></td>
</tr>

<tr>
  <th>instrument</th>
  <td><? print $instrument ?></td>
</tr>

<tr>
  <th>anim1</th>
  <td><? print $anim1 ?></td>
</tr>

<tr>
  <th>anim2</th>
  <td><? print $anim2 ?></td>
</tr>

<tr>
  <th>anim3</th>
  <td><? print $anim3 ?></td>
</tr>

<tr>
  <th>place</th>
  <td><? print $place ?></td>
</tr>

<tr>
  <th>vegetable</th>
  <td><? print $vegetable ?></td>
</tr>

<tr>
  <th>structure</th>
  <td><? print $structure ?></td>
</tr>

<tr>
  <th>action</th>
  <td><? print $action ?></td>
</tr>

</table>
<form>
</html>
