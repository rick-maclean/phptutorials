<html>
<head>
<title>Three Plus Five</title>
</head>
<body>
<h1>Three Plus Five</h1>
<h3>Demonstrates use of numeric variables</h3>

<?
$x = 3;
$y = 5;

print "$x + $y = ";
print $x + $y;
print "<br><br>";

print "$x - $y = ";
print $x - $y;
print "<br><br>";

print "$x * $y = ";
print $x * $y;
print "<br><br>";

print "$x / $y = ";
print $x / $y;
print "<br><br>";

?>


</body>
</html>