<html>
<head>
<title>Row Your Boat</title>
</head>
<body>
<h1>Row Your Boat</h1>
<h3>Demonstrates use of long variables</h3>

<?

$verse = <<<HERE

Row, Row, Row, your boat<br>
Gently Down the stream<br>
Merrily, Merrily, Merrily, Merrily<br>
Life is but a dream!<br>
<br><br>
HERE;

print "<h3>Verse 1:</h3>";
print $verse;

print "<h3>Verse 2:</h3>";
print $verse;
print "<h3>Verse 3:</h3>";
print $verse;

?>


</body>
</html>
