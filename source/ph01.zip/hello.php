<html>
<head>
<title>Hello in PHP</title>
</head>
<body>
<h1>Hello in PHP</h1>

<? print "Hello, world!"; 
   phpInfo();
?>

</body>
</html>
