<html>
<head>
<title>Tip of the day</title>
</head>

<body>
<center>

<h1>Tip of the day</h1>
<? 

print "<h3>Here's your tip:</h3>";
?>

<div style = "border-color:green; border-style:groove; border-width:2px">
<?
readfile("tips.txt");
?>
</div>


</center>
</body>
</html>