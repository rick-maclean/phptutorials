<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Show Segment</title>
<style type = "text/css">
body {
  color:red
}
td {
  color: white;
  background-color: blue;
  width: 20%;
  height: 3em;
  font-size: 20pt
}
</style>
</head>
<body>
<?
if (empty($room)){
  $room = 1;
} // end if

//connect to database
$conn  = mysql_connect("localhost", "", "");
$select = mysql_select_db("chapter7", $conn);
$sql = "SELECT * FROM adventure WHERE id = '$room'";
$result = mysql_query($sql);
$mainRow = mysql_fetch_assoc($result);
$theText = $mainRow["description"];


/*
//print "theText is $theText<br>\n";
foreach ($mainRow as $key=>$value){
  print "$key: $value<br>\n";
} // end foreach
*/

$northButton = buildButton("north");
$eastButton = buildButton("east");
$westButton = buildButton("west");
$southButton = buildButton("south");
$roomName = $mainRow["name"];

print <<<HERE
<center><h1>$roomName</h1></center>
<form method = "post">
<table border = 1>
<tr>
  <td></td>
  <td>$northButton</td>
  <td></td>
</tr>

<tr>
  <td>$eastButton</td>
  <td>$theText</td>
  <td>$westButton</td>
</tr>

<tr>
  <td></td>
  <td>$southButton</td>
  <td></td>
</tr>

</table>
<center>
<input type = "submit"
       value = "go">
</center>
</form>

HERE;

function buildButton($dir){
  //builds a button for the specified direction
  global $mainRow, $conn;
  $newID = $mainRow[$dir];
  //print "newID is $newID";
  $query = "SELECT name FROM adventure WHERE id = $newID";
  $result = mysql_query($query, $conn);
  $row = mysql_fetch_assoc($result);
  $roomName = $row["name"];

  $buttonText = <<< HERE
  <input type = "radio"
         name = "room"
         value = "$newID">$roomName

HERE;

  return $buttonText;

} // end build button
?>
</body>
</html>
