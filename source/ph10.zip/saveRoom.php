<html>
<head>
<title>SaveRoom.php</title>
</head>
<body>

<?
//Once a room has been edited by editSegment, this program
//updates the database accordingly.

//check to see what values came in
/*
foreach ($_REQUEST as $key=>$value){
  print "$key: $value<br>";
} // end foreach
*/

//connect to database
$conn  = mysql_connect("localhost", "", "");
$select = mysql_select_db("chapter7", $conn);

$sql = <<<HERE
UPDATE adventure
SET
  name = '$name',
  description = '$description',
  north = $north,
  east = $east,
  south = $south,
  west = $west
WHERE
  id = $id

HERE;

//print $sql;
$result = mysql_query($sql);
if ($result){
  print "<h3>$name room updated successfully</h3>\n";
  print "<a href = \"listSegments.php\">view the rooms</a>\n";
} else {
  print "<h3>There was a problem with the database</h3>\n";
} // end if

?>
</body>
</html>
