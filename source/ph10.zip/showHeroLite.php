<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
<title>SQLite Hero Demo</title>
</head>
<body>
<?
//Connect to the hero database using SQLite.

$db = sqlite_open("chapter8.db");
$query = "SELECT * FROM hero";
$result = sqlite_query($db, $query);

print "<table border = 1>\n";
while ($row = sqlite_fetch_array($result, SQLITE_ASSOC)){
  print "  <tr> \n";
  foreach ($row as $field => $value){
    //print "<td>$field</td>\n";
    print "<td>$value</td>\n";
  } // end foreach
  print "</tr> \n";
} // end while
print "</table> \n";




?>
</body>
</html>
