<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Add a Record</title>
</head>
<body>
<h2>Add Record</h2>
<?
include "spyLib.php";

$dbConn = connectToSpy();

print tToAdd($tableName);
print mainButton();

?>

</body>
</html>
