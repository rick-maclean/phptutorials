
<html>
<head>
<title>Spy Master Main Page</title>
<?
  include "spyLib.php";
?>

</head>
<body>
<form action = "viewQuery.php"
      method = "post">

<table border = 1
       width = 200>
<tr>
  <td><center><h2>View Data</h2></center></td>
</tr>

<tr>
  <td><center>
    <select name = "theQuery" size = 10>
<?
//get queries from storedQuery table

$dbConn = connectToSpy();
$query = "SELECT * from storedQuery";
$result = mysql_query($query, $dbConn);
while($row = mysql_fetch_assoc($result)){
  $currentQuery = $row['text'];
  $theDescription = $row['description'];
  print <<<HERE
      <option value = "$currentQuery">$theDescription</option>
  
HERE;
  } // end while

?>
    </select>
  </center>
</tr>

<tr>
  <td><center>
    <input type = "submit"
       value = "execute request" >
  </center></td>
</tr>
</table>

</form>

<hr>
<form action = "editTable.php"
      method = "post">
      
<table border = 1>
<tr>
  <td colspan = 2><center>
    <h2>Edit / Delete table data</h2>
  </center></td>
</tr>

<tr>
  <td>Password:</td>
  <td>
    <input type = "password"
       name = "pwd"
       value = "absolute"><br>
  </td>
</tr>

<tr>
  <td colspan = 2><center>
    <select name = "tableName"
        size = 5>
      <option value = "agent">agents</option>
      <option value = "specialty">specialties</option>
      <option value = "operation">operations</option>
      <option value = "agent_specialty">agent_specialty</option>
      <option value = "storedQuery">storedQuery</option>
    </select>
  </center></td>
</tr>

<tr>
  <td colspan = 2><center>
    <input type = "submit"
       value = "edit table">
  </center></td>
</tr>
</table>

</form>

</body>
</html>
