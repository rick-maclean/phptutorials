<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Update Record</title>
</head>
<body>

<h2>Update Record</h2>
<?

include "spyLib.php";

$dbConn = connectToSpy();

$fieldNames = "";
$fieldValues = "";

foreach ($_REQUEST as $fieldName => $value){
  if ($fieldName == "tableName"){
    $theTable = $value;
  } else {

    $fields[] = $fieldName;
    $values[] = $value;
  } // end if
} // end foreach



print updateRec($theTable, $fields, $values);

print mainButton();

?>
</body>
</html>
