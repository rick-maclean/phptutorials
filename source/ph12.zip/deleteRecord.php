<html>
<head>
<title>Delete Record</title>
</head>
<body>
<h2>Delete Record</h2>
<?

include "spyLib.php";

$dbConn = connectToSpy();
print delRec($tableName, $keyName, $keyVal);
print mainButton();
?>

</body>
</html>
