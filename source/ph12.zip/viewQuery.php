<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>View Query</title>
</head>
<body>

<center>
<h2>Query Results</h2>
</center>
<?
include "spyLib.php";

$dbConn = connectToSpy();

//take out escape characters...
$theQuery = str_replace("\'", "'", $theQuery);

print qToTable($theQuery);

print mainButton();

?>

</body>
</html>
