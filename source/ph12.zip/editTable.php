<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Edit table</title>
</head>
<body>
<h2>Edit Table</h2>
<?
include "spyLib.php";

//check password

if ($pwd == $adminPassword){
  $dbConn = connectToSpy();
  print tToEdit("$tableName");
} else {
  print "<h3>You must have administrative access to proceed</h3>\n";
} // end if
print mainButton();

?>
</body>
</html>
