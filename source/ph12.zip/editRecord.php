<html>
<head>
<title>Edit Record</title>
</head>
<body>
<h1>Edit Record</h1>
<?

// expects $tableName, $keyName, $keyVal
include "spyLib.php";

$dbConn = connectToSpy();

$query = "SELECT * FROM $tableName WHERE $keyName = $keyVal";
print smartRToEdit($query);

print mainButton();

?>
</body>
</html>
