-- chapter 9 and 10 databases
-- for SQLite


DROP TABLE hero;
DROP TABLE phonelist;

CREATE TABLE hero (
  id INTEGER PRIMARY KEY,
  name varchar(30),
  power varchar(30),
  weapon varchar(30),
  transportation varchar(30)
);

INSERT INTO hero VALUES (0, 'Professor One', 'Earthquake generation', 'Laser Pointer', 'Binary Cow');
INSERT INTO hero VALUES (1, 'Bat Worm', 'Super Speed', 'Worm belt', 'Bat taxi');
INSERT INTO hero VALUES (2, 'Millennium Panther', 'Death Breath', 'Panther Bullets', 'Panther Submarine');
INSERT INTO hero VALUES (3, 'Lightning Guardian', 'Electric Toe', 'Guardian Missles', 'Guardian Moped');
INSERT INTO hero VALUES (4, 'Yak-Bot', 'Super Yurt', 'Yakbutter flamethrower', 'Yak Dirigible');

create table phonelist(
  id INTEGER PRIMARY KEY,
  firstname VARCHAR(15),
  lastname VARCHAR(15),
  email VARCHAR(20),
  phone VARCHAR(15)
);
  INSERT INTO phonelist   VALUES(0,'Andy','Harris','aharris@cs.iupui.edu','123-4567');
  INSERT INTO phonelist   VALUES(1,'Joe','Slow','jslow@noplace.net','987-6543');

CREATE TABLE adventure (
  id INTEGER PRIMARY KEY,
  name varchar(20),
  description varchar(200),
  north int(11),
  east int(11),
  south int(11),
  west int(11)
);

INSERT INTO adventure VALUES (0, 'lost', 'You cannot go that way!', 1, 0, 0, 0);
INSERT INTO adventure VALUES (1, 'start', 'You are at a submarine yard, looking for the famous Enigma code machine', 0, 3, 0, 2);
INSERT INTO adventure VALUES (2, 'sub deck', 'As you step on the submarine deck, a guard approaches you.  Your only choice is to jump off the sub before you are caught.', 15, 15, 15, 15);
INSERT INTO adventure VALUES (3, 'warehouse', 'You wait inside the warehouse.  You see a doorway to the south and a box to the east.', 0, 4, 5, 0);
INSERT INTO adventure VALUES (4, 'doorway', 'You walked right into a group of guards. It does not look good...', 0, 19, 0, 15);
INSERT INTO adventure VALUES (5, 'box', 'You crawl inside the box and wait. Suddenly, you feel the box being picked up and carried across the wharf!', 6, 0, 0, 7);
INSERT INTO adventure VALUES (6, 'wait', '..You wait until the box settles in a dark space. You can move forward or aft...', 8, 0, 9, 0);
INSERT INTO adventure VALUES (7, 'jump out', 'You decide to jump out of the box, but you are cornered at the end of the wharf.', 15, 19, 15, 15);
INSERT INTO adventure VALUES (8, 'forward', 'As you move forward, two rough sailors grab you and hurl you out of the conning tower.', 15, 15, 15, 15);
INSERT INTO adventure VALUES (9, 'aft', 'In a darkened room, you see the enigma device. How will you get it out of the sub?', 13, 11, 10, 12);
INSERT INTO adventure VALUES (10, 'signal on enigma', 'You use the enigma device to send a signal. Allied forces recognize your signal and surround the ship when it surfaces', 14, 0, 0, 0);
INSERT INTO adventure VALUES (11, 'shoot your way out', 'A gunfight on a submerged sub is a bad idea...', 19, 0, 0, 0);
INSERT INTO adventure VALUES (12, 'wait with enigma', 'You wait, but the sailors discover that enigma is missing and scour the sub for it. You are discovered and cast out in the torpedo tube.', 15, 0, 0, 0);
INSERT INTO adventure VALUES (13, 'replace enigma and w', 'You put the enigma back in place and wait patiently, but you never get another chance. You are discovered when the sub pulls in to harbor.', 19, 0, 0, 0);
INSERT INTO adventure VALUES (14, 'Win', 'Congratulations! You have captured the device and shortened the war!', 1, 0, 0, 0);
INSERT INTO adventure VALUES (15, 'Water', 'You are in the water. The sub moves away. It looks bad...', 19, 0, 0, 0);
INSERT INTO adventure VALUES (16, '', '', 0, 0, 0, 0);
INSERT INTO adventure VALUES (17, '', '', 0, 0, 0, 0);
INSERT INTO adventure VALUES (18, '', '', 0, 0, 0, 0);
INSERT INTO adventure VALUES (19, 'Game Over', 'The game is over. You lose.', 1, 0, 0, 0);
 
