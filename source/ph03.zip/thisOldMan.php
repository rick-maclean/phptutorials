<html>
<head>
<title>This Old Man</title>
</head>
<body>
<h1>This Old Man</h1>
<h3>Demonstrates use of functions</h3>
<?

verse1();
chorus();
verse2();
chorus();

function verse1(){
  print <<<HERE
  This old man, he played 1<br>
  He played knick-knack on my thumb<br><br>
HERE;
} // end verse1

function verse2(){
  print <<<HERE
  This old man, he played 2<br>
  He played knick-knack on my shoe<br><br>
HERE;
} // end verse1

function chorus(){
  print <<<HERE
  ...with a knick-knack<br>
  paddy-whack<br>
  giva a dog a bone<br>
  this old man came rolling home<br>
  <br><br>
HERE;
} // end chorus

?>
</body>
</html>