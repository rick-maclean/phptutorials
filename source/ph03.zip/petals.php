<HTML>
<head>
<title>Petals Around the Rose</title>
</head>
<body bgcolor = "tan">
<center>
<font face = "Comic Sans MS">
<h1>Petals Around the Rose</h1>

<?

printGreeting();
printDice();
printForm();


function printGreeting(){
  global $guess, $numPetals;
  if ($guess == null){
    print "<h3>Welcome to Petals Around the Rose</h3>";
  } else if ($guess == $numPetals){
    print "<h3>You Got It!</h3>";
  } else {

    print <<<HERE

      <h3>from last try: </h3>
      you guessed: $guess<br><br>
      -and the correct answer was: $numPetals petals around the rose<br>
HERE;

  } // end if

} // end printGreeting

function showDie($value){
  print <<<HERE
  <img src = "die$value.jpg"
       height = 100
       width = 100>
HERE;
} // end showDie

function printDice(){
  global $numPetals;

  print "<h3>New Roll:</h3>";
  $numPetals = 0;
  
  $die1 = rand(1,6);
  $die2 = rand(1,6);
  $die3 = rand(1,6);
  $die4 = rand(1,6);
  $die5 = rand(1,6);
  
  showDie($die1);
  showDie($die2);
  showDie($die3);
  showDie($die4);
  showDie($die5);
  
  print "<br>";
  
  calcNumPetals($die1);
  calcNumPetals($die2);
  calcNumPetals($die3);
  calcNumPetals($die4);
  calcNumPetals($die5);

} // end printDice


function calcNumPetals($value){

  global $numPetals;

  switch ($value) {
    case 3:
      $numPetals += 2;
      break;
    case 5:
      $numPetals += 4;
      break;
  } // end switch

} // end calcNumPetals

function printForm(){
  global $numPetals;
  
  print <<<HERE

  <h3>How many petals around the rose?</h3>

  <form method = "post">
  <input type = "text"
         name = "guess"
         value = "0">
  <input type = "hidden"
         name = "numPetals"
         value = "$numPetals">
  <br>
  <input type = "submit">
  </form>
  <br>
  <a href = "petalHelp.html" 
     target = "helpPage">
  give me a hint</a>
HERE;

} // end printForm

?>
</font>
</center>
</body>
</HTML>

