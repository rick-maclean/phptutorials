<html>
<head>
<title>Ace or Not</title>
</head>
<body>
<h1>Ace or Not</h1>
<h3>Demonstrates if statement with else clause</h3>

<?
$roll = rand(1,6);
print "You rolled a $roll";
print "<br>";

if ($roll == 1){
  print "<h1>That's an ace!!!!!</h1>";
} else {
  print "That's not an ace...";
} // end if

print "<br>";
print "<img src = die$roll.jpg>";
?>
<br>
Refresh this page in the browser to roll another die.

</body>
</html>

