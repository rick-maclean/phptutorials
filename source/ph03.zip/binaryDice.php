<html>
<head>
<title>Binary Dice</title>
</head>
<body>
<h1>Binary Dice</h1>
<h3>Demonstrates multiple if structure</h3>

<?
$roll = rand(1,6);
print "You rolled a $roll";
print "<br>";

if ($roll == 1){
  $binValue = "001";
} else if ($roll == 2){
  $binValue = "010";
} else if ($roll == 3){
  $binValue = "011";
} else if ($roll == 4){
  $binValue = "100";
} else if ($roll == 5){
  $binValue = "101";
} else if ($roll == 6){
  $binValue = "110";
} else {
  print "I don't know that one...";
} // end if


print "<br>";
print "<img src = die$roll.jpg>";
print "<br>";
print "In binary, that's $binValue";
print "<br>";
print "<br>";
print "<br>";

?>
<br>
Refresh this page in the browser to roll another die.

</body>
</html>


