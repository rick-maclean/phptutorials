<html>
<head>
<title>Hi User</title>
</head>
<body>  
<h1>Hi User</h1>

<? 

if ($userName == ""){
?>
<form>
Please enter your name:
<input type = "text"
       name = "userName"><br>
<input type = "submit">
</form>

<?
} else {
  print "<h3>Hi there, $userName!</h3>";
} //end
?>

</body>
</html>




