<html>
<head>
<title>Switch Dice</title>
</head>
<body>
<h1>SwitchDice</h1>
<h3>Demonstrates switch structure</h3>

<?
$roll = rand(1,6);
print "You rolled a $roll";
print "<br>";

switch ($roll){
  case 1:
    $romValue = "I";
    break;
  case 2:
    $romValue = "II";
    break;
  case 3:
    $romValue = "III";
    break;
  case 4:
    $romValue = "IV";
    break;
  case 5:
    $romValue = "V";
    break;
  case 6:
    $romValue = "VI";
    break;
  default:
    print "This is an illegal die!";
} // end switch


print "<br>";
print "<img src = die$roll.jpg>";
print "<br>";
print "In Roman numerals, that's $romValue";
print "<br>";
print "<br>";
print "<br>";

?>
<br>
Refresh this page in the browser to roll another die.

</body>
</html>


