<html>
<head>
<title>Ace!</title>
</head>
<body>
<h1>Ace!</h1>
<h3>Demonstrates if statement</h3>

<?
$roll = rand(1,6);
print "You rolled a $roll";

if ($roll == 1){
  print "<h1>That's an ace!!!!!</h1>";
} // end if

print "<br>";
print "<img src = die$roll.jpg>";
?>
<br>
Refresh this page in the browser to roll another die.

</body>
</html>