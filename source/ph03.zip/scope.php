<html>
<head>
<title>Scope Demo</title>
</head>
<body>
<h1>Scope Demo</h1>
<h3>Demonstrates variable scope</h3>

<?

$a = "I have a value";
$b = "I have a value";

print <<<HERE
  outside the function, <br>
  \$a is "$a", and<br>
  \$b is "$b"<br><br>
HERE;

myFunction();

function myFunction(){

  //make $a global, but not $b
  global $a;

  print <<<HERE
    inside the function, <br>
    \$a is "$a", and<br>
    \$b is "$b"<br><br>
HERE;
} // end myFunction

?>

</body>
</html>