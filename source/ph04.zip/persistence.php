<html>
<head>
<title>
persistence demo
</title>
</head>

<body>

<h1>Persistence Demo</h1>
<form>
<?
//increment the counters
$txtBoxCounter++;
$hdnCounter++;

print <<<HERE

<input type = "text"
       name = "txtBoxCounter"
       value = "$txtBoxCounter">
       
<input type = "hidden"
       name = "hdnCounter"
       value = "$hdnCounter">
<h3>The hidden value is $hdnCounter</h3>
<input type = "submit"
       value = "click to increment counters">
HERE;

?>

</form>
</body>
</html>



