<html>

<head>
<title>
Counting By Fives
</title>
</head>

<body>

<h1>Counting By Fives</h1>

<?

for ($i = 5; $i <= 50; $i+= 5){
  print "$i <br>\n";
} // end for loop

?>


</body>
</html>
