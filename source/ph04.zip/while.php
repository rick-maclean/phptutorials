<html>

<head>
<title>
A simple While Loop
</title>
</head>

<body>

<h1>A simple while loop</h1>

<?

$i = 1;

while ($i <= 10){
  print "$i <br>\n";
  $i++;
} // end while	

?>


</body>
</html>

