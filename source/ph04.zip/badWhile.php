<html>

<head>
<title>
A bad While Loop
</title>
</head>

<body>

<h1>A bad while loop</h1>

<?

$i = 1;

while ($i <= 10){
  print "$i <br>\n";
  $j++;
} // end while	

?>


</body>
</html>

