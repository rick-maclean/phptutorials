<html>

<head>
<title>
Counting Backwards
</title>
</head>

<body>

<h1>Counting Backwards</h1>

<?

for ($i = 10; $i > 0; $i--){
  print "$i <br>\n";
} // end for loop

?>


</body>
</html>

