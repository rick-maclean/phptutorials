<html>

<head>
<title>
A simple For Loop
</title>
</head>

<body>

<h1>A simple for loop</h1>

<?

for ($i = 0; $i < 10; $i++){
  print "$i <br>\n";
} // end for loop

?>


</body>
</html>



