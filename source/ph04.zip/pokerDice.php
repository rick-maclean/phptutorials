<html>
<head>
<title>poker dice</title>
<style type = "text/css">
body {
  background: green;
  color: tan;
}

</style>
</head>

<body>
<center>
<h1>Poker Dice</h1>

<form>

<?
//check to see if this is first time here
if (!$cash){
  $cash = 100;
} // end if

rollDice();

if ($secondRoll == TRUE){
  print "<h2>Second roll</h2>\n";
  $secondRoll = FALSE;
  evaluate();
} else {
  print "<h2>First roll</h2>\n";
  $secondRoll = TRUE;
} // end if

printStuff();

  
function rollDice(){
  global $die, $secondRoll, $keepIt;

  print "<table border = 1><td><tr>";
  
  for ($i = 0; $i < 5; $i++){
  	if ($keepIt[$i] == ""){
      $die[$i] = rand(1, 6);
  	} else {
      $die[$i] = $keepIt[$i];
  	} // end if
    $theFile = "die" . $die[$i] . ".jpg";

    //print out dice images
    print <<<HERE
    <td>
    <img src = "$theFile"
         height = 50
         width = 50><br>
         
HERE;
    //print out a checkbox on first roll only
    if ($secondRoll == FALSE){
      print <<<HERE
    <input type = "checkbox"
           name = "keepIt[$i]"
           value = $die[$i]>
    </td>

HERE;

    } // end if
  } // end for loop

  //print out submit button and end of table
  print <<<HERE
  </tr></td>
  <tr>
    <td colspan = "5">
    <center>
    <input type = "submit"
           value = "roll again">
    </center>
    </td>
  </tr>
  </table>

HERE;
  	
} // end rollDice

function evaluate(){
  global $die, $cash;
  //set up payoff
  $payoff = 0;
  
  //subtract some money for this roll
  $cash -= 2;
  
  //count the dice
  for ($theVal = 1; $theVal <= 6; $theVal++){
  	for ($dieNum = 0; $dieNum < 5; $dieNum++){
  	  if ($die[$dieNum] == $theVal){
  	    $numVals[$theVal]++;
  	  } // end if
  	} // end dieNum for loop
  } // end theVal for loop
  
  //print out results
  //  for ($i = 1; $i <= 6; $i++){
  //  	print "$i:  $numVals[$i]<br>\n";
  //  } // end for loop
  
  //count how many pairs, threes, fours, fives
  $numPairs = 0;
  $numThrees = 0;
  $numFours = 0;
  $numFives = 0;
  
  for ($i = 1; $i <= 6; $i++){
    switch ($numVals[$i]){
      case 2:
        $numPairs++;
        break;
      case 3:
        $numThrees++;
        break;
      case 4:
        $numFours++;
        break;
      case 5:
        $numFives++;
        break;
    } // end switch
  } // end for loop

  //check for two pairs
  if ($numPairs == 2){
    print "You have two pairs!<br>\n";
    $payoff = 1;
  } // end if
  
  //check for three of a kind and full house
  if ($numThrees == 1){
    if ($numPairs == 1){
      //three of a kind and a pair is a full house
      print "You have a full house!<br>\n";
      $payoff = 5;
    } else {
      print "You have three of a kind!<br>\n";
      $payoff = 2;
    } // end 'pair' if
  } // end 'three' if

  //check for four of a kind
  if ($numFours == 1){
    print "You have four of a kind!<br>\n";
    $payoff = 5;
  } // end if
  
  //check for five of a kind
  if ($numFives == 1){
    print "You got five of a kind!<br>\n";
    $payoff = 10;
  } // end if
  
  //check for flushes
  if (($numVals[1] == 1)
    && ($numVals[2] == 1)
    && ($numVals[3] == 1)
    && ($numVals[4] == 1)
    && ($numVals[5] == 1)){
    print "You have a flush!<br>\n";
    $payoff = 10;
  } // end if

  if (($numVals[2] == 1)
    && ($numVals[3] == 1)
    && ($numVals[4] == 1)
    && ($numVals[5] == 1)
    && ($numVals[6] == 1)){
    print "You have a flush!<br>\n";
    $payoff = 10;
          
  } // end if
  print "You bet 2<br>\n";
  print "Payoff is $payoff<br>\n";
  $cash += $payoff;
   
} // end evaluate
  
function printStuff(){
  global $cash, $secondRoll;
  
  print "Cash: $cash\n";
    
  //store variables in hidden fields
  print <<<HERE
  <input type = "hidden"
         name = "secondRoll"
         value = "$secondRoll">

  <input type = "hidden"
         name = "cash"
         value = "$cash">
           
HERE;
} // end printStuff

?>

</form>
</center>
</html>