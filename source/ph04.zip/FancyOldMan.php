<html>
<head>
<title>
Fancy Old Man
</title>
</head>
<body>
<h1>This Old Man with Arrays</h1>
<pre>
<?
$place = array(
  "",
  "on my thumb",
  "on my shoe",
  "on my knee",
  "on a door");
  
//print out song
for ($verse = 1; $verse <= 4; $verse++){
print <<<HERE
 This old man, He played $verse
 He played knick-knack $place[$verse]
 ...with a knick, knack, paddy-whack
 give a dog a bone
 This old man came rolling home 

 
HERE;
  } // end for loop

?>
</pre>
</body>
</html>